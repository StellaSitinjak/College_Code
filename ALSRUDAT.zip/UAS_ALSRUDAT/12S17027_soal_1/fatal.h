/*
Nama: Stella Ditri Almeyda Sitinjak
NIM: 12S17027
*/

#include <stdio.h>
#include <stdlib.h>

#define Error(Str)		FatalError(Str)
#define FatalError(Str)	fprintf( stderr, "%s\n", Str), exit( 1 )
