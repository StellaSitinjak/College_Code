/*
Nama: Stella Ditri Almeyda Sitinjak
NIM: 12S17027
*/

typedef int ElementType;

#ifndef _Tree_H
#define _Tree_H

struct TreeNode;
typedef struct TreeNode *Position;
typedef struct TreeNode *BinarySearchTree;

BinarySearchTree Insert(ElementType x, BinarySearchTree T);
BinarySearchTree Insert_Iterative(ElementType x, BinarySearchTree T);
Position Find(ElementType x, BinarySearchTree T);
ElementType Retrieve(Position P);
BinarySearchTree MakeEmpty(BinarySearchTree T);
Position FindMin(BinarySearchTree T);
Position FindMax(BinarySearchTree T);
BinarySearchTree Delete(ElementType x, BinarySearchTree T);
void PrintInOrder(BinarySearchTree T);
unsigned int GetNumNodes(BinarySearchTree T);
int is_bst_balance(BinarySearchTree T);
int count_height(Position P);
int Max(int Left, int Right);

#endif
