/*
Nama: Stella Ditri Almeyda Sitinjak
NIM: 12S17027
*/

#include "binary_search_tree.h"
#include <stdlib.h>
#include "fatal.h"
#include <limits.h>

struct TreeNode{
	ElementType Element;
	BinarySearchTree Left;
	BinarySearchTree Right;
};

BinarySearchTree MakeEmpty(BinarySearchTree T){
	if(T != NULL){
		MakeEmpty(T->Left);
		MakeEmpty(T->Right);
		free(T);
	}
	return NULL;
}

//Fungsi Insert Rekursif
BinarySearchTree Insert(ElementType x, BinarySearchTree T){
	if(T == NULL){
		T = malloc(sizeof(struct TreeNode));
		if(T == NULL)
			FatalError("Out of space!!!");
		else{
			T->Element = x;
			T->Left = T->Right = NULL;
		}
	}
	else if(x < T->Element){
		T->Left = Insert(x, T->Left);
	}
	else if(x > T->Element){
		T->Right = Insert(x, T->Right);
	}
	//printf("C imp: T->Element = %d \n", T->Element);
	
	return T;
}

//Fungsi Insert Iteratif
BinarySearchTree Insert_Iterative(ElementType x, BinarySearchTree T){
	BinarySearchTree Node = malloc(sizeof(struct TreeNode));
	Node->Element = x;
	Node->Right = Node->Left = NULL;
	if(T == NULL){
		return Node;
	}
	BinarySearchTree Parent = NULL, Current = T;
	while(Current != NULL){
		Parent = Current;
		if(x >= Current->Element){
			Current = Current->Right;
		}
		else{
			Current = Current->Left;
		}
	}
	if(x >= Parent->Element){
		Parent->Right = Node;
	}
	else{
		Parent->Left = Node;
	}
	return T;
}

ElementType Retrieve(Position P){
	return P->Element;
}

//Fungsi find berdasarkan nilai elemen
Position Find(ElementType x, BinarySearchTree T){
	if(T == NULL)
		return NULL;
	else if(x == T->Element)
		return T;
	else if(x < T->Element)
		return Find(x, T->Left);
	else if(x > T->Element)
		return Find(x, T->Right);
}

Position FindMin(BinarySearchTree T){
	if(T == NULL)
		return NULL;
	else if(T->Left == NULL)
		return T;
	else
		return FindMin(T->Left);
}

Position FindMax(BinarySearchTree T){
	if(T != NULL)
		while(T->Right != NULL)
			T = T->Right;
	return T;
}

BinarySearchTree Delete(ElementType x, BinarySearchTree T){
	Position TmpCell;
	
	if(T == NULL)
		Error("Element not found");
	else if(x < T->Element) /*Go Left*/
		T->Left = Delete (x, T->Left);
	else if(x > T->Element) /*Go Right*/
		T->Right = Delete(x, T->Right);
	else /* Found element to be deleted*/
		if(T->Left && T->Right ){ /*Two children*/
			/* Replace with smallest in right subtree*/
			TmpCell = FindMin(T->Right);
			T->Element = TmpCell->Element;
			T->Right = Delete(T->Element, T->Right);
		}
		else{ /* One or zero children*/
			TmpCell = T;
			if(T->Left == NULL) /* Also handles 0 children*/
				T = T->Right;
			else if(T->Right == NULL)
				T = T->Left;
			free(TmpCell);
		}
	return T;
}

unsigned int GetNumNodes(BinarySearchTree T){
	if(T == NULL)
		return 0;
	else
		return GetNumNodes(T->Left) + 1 + GetNumNodes(T->Right);
}

void PrintInOrder(BinarySearchTree T){
	if(T != NULL){
		PrintInOrder(T->Left);
		printf("%d\n", T->Element);
		PrintInOrder(T->Right);
	}
}

int max(int left, int right){
	if(left > right)
		return left;
	else
		return right;
}

int count_height(Position P){
	if(P == NULL)
		return 0;
	else if(!(P->Left && P->Right))
		return 1;
	else{
		int left_height = count_height(P->Left);
		int right_height = count_height(P->Right);
		return max(left_height, right_height) + 1;
	}
}

int is_bst_balance(BinarySearchTree T){
	if(count_height(T) <= 1)
		return 1;
	else
		return 0;
}

int depth[100000];
int get_node_depth(BinarySearchTree T, ElementType x){
	if(T == NULL){
		printf("Binary Search Tree is not existed\n");
		return INT_MIN;
	}
	else if(Find(x, T) == NULL){
		printf("Node %d is not existed\n", x);
		return INT_MIN;
	}
	else if(T != NULL && Find(x, T) != NULL){
		if(!(T->Left && T->Right))
			return 1;
		else if(x == T->Element || depth[x] != 0)
			return depth[x];
		else{
			depth[T->Right->Element] = depth[T->Left->Element] = depth[T->Element] + 1;
			if(x < T->Element)
				get_node_depth(T->Left, x);
			else if(x > T->Element)
				get_node_depth(T->Right, x);
		}
	}
}

