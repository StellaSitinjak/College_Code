/*
Nama: Stella Ditri Almeyda Sitinjak
NIM: 12S17027
*/

#include "binary_search_tree.h"
#include <stdio.h>
#include <limits.h>

int main(){
	BinarySearchTree T;
	Position P = NULL;
	
	//Pembuatan Binary Search Tree
	T = MakeEmpty(NULL);
	
	//Memasukkan nilai elemen pada Binary Search Tree
	T = Insert(6, T);
	T = Insert(2, T);
	T = Insert(8, T);
	T = Insert(1, T);
	T = Insert(4, T);
	T = Insert(7, T);
	T = Insert(10, T);
	T = Insert(9, T);
	T = Insert(15, T);
	T = Insert(13, T);
	T = Insert(17, T);
	
	//Mengambil nilai elemen pada root
	printf("Root = %d\n", Retrieve(T));
		
	//Mencari elemen minimum
	P = FindMin(T);
	printf("Minimum element = %d\n", Retrieve(P));
	
	//Mencari elemen maksimum
	P = FindMax(T);
	printf("Maximum element = %d\n", Retrieve(P));
	
	//Memasukkan data baru dengan elemen 25
	T = Insert(25, T);
	
	//Mencari simpul dengan nilai elemen 25
	P = Find(25, T);
	printf("Node with element %d is added to tree.\n", Retrieve(P));
	
	//Mencari simpul dengan nilai elemen 30
	if(Find(30, T) == NULL)
		printf("Node with element 30 is not found.\n");
	else
		printf("Node with element 30 is found.\n", Retrieve(P));

	//Pengecekan keseimbangan pohon
	if(is_bst_balance(T) == 1)
		printf("Binary search tree IS balance.\n");
	else
		printf("Binary search tree is NOT balance.\n");
	
	//Mencari kedalaman simpul
	int i, num[3] = {6, 9, 30};
//	int num[12] = {6, 2, 8, 1, 4, 7, 10, 9, 15, 13, 17, 30};
//	for(i = 0; i < 12; i++){
	for(i = 0; i < 3; i++){
		if(get_node_depth(T, num[i]) == INT_MIN)
			printf("The depth of node %d is undefined because it is not existed.\n", num[i]);
		else
			printf("The depth of node %d = %d\n", num[i], get_node_depth(T, num[i]));
	}

	return 0;
}
