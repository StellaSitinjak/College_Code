/*
Nama: Stella Ditri Almeyda Sitinjak (12S17027)
	  Silvany Angelia Lumban Gaol (12S17029)
	  Fradina Sinambela (12S17067)
*/

typedef unsigned int ElementType;

#ifndef Graph_H
#define _Graph_H

struct GraphNode;
typedef struct GraphNode *PtrToGraphNode;
typedef PtrToGraphNode Edge;
typedef PtrToGraphNode Node;
struct GraphADT;
typedef struct GraphADT *PtrToGraph;
typedef PtrToGraph Graph;
struct subset;
typedef struct subset *PtrToSubset;
typedef PtrToSubset Subset;

Graph ConstructGraph(ElementType V);
unsigned int GetNumberOfNodes (Graph g);
Graph AddNode(Graph g, ElementType X);
Node SearchNode(Graph g, ElementType X);
ElementType GetNodeID(Node node);
Graph AddEdge (Graph g, ElementType Start, ElementType End, int weight);
int *GetNeighbours (Graph g, ElementType ID);
void DFS(Graph g,ElementType start,ElementType end);
void printGraph(Graph graph);
void PrintNode(Graph g, int n);
int myComp(const void* a, const void* b);
int Find(Subset subsets, int i) ;
void Union(Subset subsets, int x, int y);

#endif
