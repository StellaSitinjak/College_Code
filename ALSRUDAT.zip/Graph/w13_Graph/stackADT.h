/*
Nama: Stella Ditri Almeyda Sitinjak (12S17027)
	  Silvany Angelia Lumban Gaol (12S17029)
	  Fradina Sinambela (12S17067)
*/

#ifndef _Stack_h
#define _Stack_h

typedef int ElmtTypeS;
struct Node;
typedef struct Node *PtrToNode;
typedef PtrToNode Stack;

Stack CreateStack(void);
void Push(ElmtTypeS X, Stack S);
ElmtTypeS Top(Stack S);
int IsEmpty(Stack S);
void Pop(Stack S);
void MakeEmpty(Stack S);
void DisposeStack(Stack S);

#endif
