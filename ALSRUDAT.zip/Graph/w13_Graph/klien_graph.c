/*
Nama: Stella Ditri Almeyda Sitinjak (12S17027)
	  Silvany Angelia Lumban Gaol (12S17029)
	  Fradina Sinambela (12S17067)
*/

#include <stdio.h>
#include "graphADT.h"

int main(int argc, char *argv[]){
	Node node;
	int *neighbours, i;
	
	Graph G = ConstructGraph(7);	//construct graph with 7 nodes
	int V = GetNumberOfNodes(G);	//get number of nodes
	printf("Number of Nodes in Graph: %u\n", V);
	
	//add node 1 to 7 to graph G iteratively
	for(i=0; i<=1; i++){
		G = AddNode(G, i);
		printf("%d\n",i);
	}
	for(i=3; i<=7; i++){
		G = AddNode(G, i);
		printf("%d\n",i);
	}
	//search node 7
	node = SearchNode(G, 7);
	printf("Node is found, id = %d\n\n", GetNodeID(node));
	
	//add edge, 0 weight means graph with equal weights
	G = AddEdge(G, 0, 1, 0);
	G = AddEdge(G, 0, 4, 0);
	G = AddEdge(G, 4, 3, 0);
	G = AddEdge(G, 4, 6, 0);
	G = AddEdge(G, 3, 5, 0);
	G = AddEdge(G, 6, 1, 0);
	G = AddEdge(G, 5, 7, 0);
	G = AddEdge(G, 7, 4, 0);
	G = AddEdge(G, 7, 6, 0);
	
	PrintNode(G, 7);
	DFS(G, 0, 7);

	printf("\n--Kruskal Function--\n");
//	KruskalMST(G); 

//	return 0;
	
	//get neighbours of node 7
//	neighbours = GetNeighbours(G,7);
//	for(i = 0; i < 3; i++)
//		printf("neighbours %d = %d\n", i+1, neighbours[i]);

	return 0;
}
