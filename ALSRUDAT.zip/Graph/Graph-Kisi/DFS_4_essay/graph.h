/*
Nama	: 	Boas D. Pangaribuan (12S16030)
				Antonio R. Banjarnahor (12S16043)
				Tumbur M. T. Sianturi (12S16056)
*/





//author Tennov

typedef unsigned int ElementType;

#ifndef _Graph_H
#define _Graph_H

struct GraphNode;									//structure of node
typedef struct GraphNode *PtrToGraphNode;			//pointer to struct node
typedef PtrToGraphNode Edge;						//ptr to struct node used to represent edge
typedef PtrToGraphNode Node;						//ptr to struct node used to represent node
struct GraphADT;									//structure of Graph
typedef struct GraphADT *PtrToGraph;				//pointer to struct graphdefaults
typedef PtrToGraph Graph;							//graph represented as pointer

Graph ConstructGraph(unsigned int V);				//construct an empty graph
unsigned int GetNumberOfNodes(Graph g);
Graph AddNode(Graph g, ElementType X);
Node SearchNode(Graph g, ElementType X);
ElementType GetNodeID(Node node);
Graph AddEdge(Graph g, ElementType Start, ElementType End, int weight);
int *GetNeighbours(Graph g, ElementType ID);		//get neighbours (successors) of Node ID
void DFS(Graph g,ElementType start,ElementType end);
void PrintNode(Graph g,int n);

#endif







