#include <stdio.h>
#include<stdlib.h>
#include<limits.h>
#include "graph.h"
#include "stack.c"


struct GraphNode{
	ElementType ID;
	Edge next;
	int weight;
};

struct GraphADT{
	unsigned int V;
	Node *adjlist;
};

Graph ConstructGraph(unsigned int V){
	Graph graph = malloc(sizeof(struct GraphADT));
	graph->V = V;
	graph->adjlist = malloc(V*sizeof(PtrToGraphNode));
	
	return graph;
}

unsigned int GetNumberOfNodes(Graph g){
	return g->V;
}

Graph AddNode(Graph g, ElementType X){
	static int count;
	if(count < g->V){
		g->adjlist[count] = malloc(sizeof(struct GraphNode));
		g->adjlist[count]->ID = X;
		g->adjlist[count]->next = NULL;
		count++;
		//printf("Count = %d\n", count);
	}else{
		printf("New Node cannot be added");
		exit(1);
	}
	
	return g;
}

Node SearchNode(Graph g, ElementType X){
	int i = 0;
	unsigned int limit = GetNumberOfNodes(g);
	for(i=0; i<limit; ++i){
		if(g->adjlist[i]->ID == X)
			return g->adjlist[i];
	}
	return g->adjlist[i];
}

ElementType GetNodeID(Node node){
	return node->ID;
}

Graph AddEdge(Graph g, ElementType Start, ElementType End, int weight){
	Node node = SearchNode(g, Start);
	//printf("Node %d is found, id = %d\n, Start, node->ID");
	if(node != NULL){
		while(node->next != NULL)
			node = node->next;
		Edge new = malloc(sizeof(struct GraphNode));
		new->ID = End;
		new->weight = weight;
		new->next = NULL;
		node->next = new;
	}
	return g;
}

int *GetNeighbours(Graph g, ElementType ID){
	int i = 0;
	int *neighbours = malloc(3*sizeof(int));
	
	Node node = SearchNode(g, ID);
	while(node->next != NULL){
		node = node->next;
		neighbours[i] = node->ID;
		i++;
	}
	return neighbours;
}

void DFS(Graph g,ElementType start,ElementType end){
	Stack S;
	Node node;
	Edge e;
	ElementType tmp;
	
	int i,n=GetNumberOfNodes(g);
	int a[n];
	for(i=0;i<n;i++){
		a[i]=0;
	}
	
	S=CreateStack();
	
	node = SearchNode(g,start);
	
	
	printf("Start = %u\n",start);
	printf("End   = %u\n",end);
	printf("Use DFS:\n");
	printf("(start)%u",start);
	a[start]=1;
	
	
	for( ; ; ){
		e=node->next;
		while(e!=NULL){
			if(e->ID==end){
				printf(" --> %u(end)",e->ID);
				return;
			}
			if(a[e->ID]==0){
				Push(e->ID,S);
				a[e->ID]=1;	
			}			
			e=e->next;
		}
		
		tmp=Top(S);
		Pop(S);
		printf(" --> %u",tmp);
		
		node = SearchNode(g,tmp);
		if(node==NULL){
			printf(" Node not found\n");
			return;
		}
	}
}

void PrintNode(Graph g,int n){
	int i;
	Edge e;
	for(i=0;i<n;i++){
		printf("%u",g->adjlist[i]->ID);
		e=g->adjlist[i]->next;
		while(e!=NULL){
			printf(" --> %u",e->ID);
			e=e->next;
		}
		printf("\n");
	}
}

