/*
Nama	: 	Boas D. Pangaribuan (12S16030)
				Antonio R. Banjarnahor (12S16043)
				Tumbur M. T. Sianturi (12S16056)
*/





#include <stdio.h>
#include <stdlib.h>
#include "stack.h"

struct Node{
	ElmtTypeS Element;
	PtrToNode   Next;
};

Stack CreateStack(void){
	Stack S;

	S = malloc(sizeof( struct Node));
	if( S == NULL )
		printf("Memori habis, tidak dapat dialokasi");
	S->Next = NULL;
	return S;
}

void Push(ElmtTypeS X, Stack S){
	PtrToNode TmpCell;

	TmpCell = malloc( sizeof( struct Node ) );
	if(TmpCell == NULL)
   	printf("Memori habis, tidak dapat dialokasi");
	else{
		TmpCell->Element = X;
		TmpCell->Next = S->Next;
		S->Next = TmpCell;
	}
}

ElmtTypeS Top(Stack S){
	if(!IsEmpty(S))
		return S->Next->Element;
   else 
		printf("Stack masih kosong\n");
   	return 0;         
}

int IsEmpty( Stack S ){
	return S->Next == NULL;
}

void Pop (Stack S){
	PtrToNode TmpCell;
	if(!IsEmpty(S)){
		TmpCell = S->Next;
		S->Next = TmpCell->Next;
		free(TmpCell);
	}
}

void MakeEmpty(Stack S){
	if(S == NULL){ 
		printf("Stack tidak ada\n");
		exit(0);
	}
	else{
		while(!IsEmpty(S)) 
			Pop(S);
	}
}

void DisposeStack(Stack S){
	MakeEmpty(S);
	free(S);
}


