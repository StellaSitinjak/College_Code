#include <stdio.h>
#include <stdlib.h>
#include "graph.h"

struct GraphNode{
    ElementType ID;
    Edge next;
    int weight;
};

struct GraphADT{
    unsigned int V;
    Node *adjlist;
};

struct subset 
{ 
    int parent; 
    int rank; 
}; 

Graph ConstructGraph(unsigned int V){
    Graph graph = malloc(sizeof(struct GraphADT));
    graph->V = V;
    graph->adjlist = malloc(V * sizeof(PtrToGraphNode));
    
    return graph;
};

unsigned int GetNumberOfNodes (Graph g){
    return g->V;
}

Graph AddNode(Graph g, ElementType X){
    static int count;
    if(count < g->V){
        g->adjlist[count] = malloc(sizeof(struct GraphNode));
        g->adjlist[count]->ID = X;
        g->adjlist[count]->next = NULL;
        count++;
    }else{
        printf("New Node cannot be added");
        exit(1);
    }
    return g;
}

Node SearchNode(Graph g, ElementType X){
    int i = 0;
    unsigned int limit = GetNumberOfNodes(g);
    for(i = 0 ; i < limit ; ++i){
        if(g->adjlist[i]->ID == X)
            return g->adjlist[i];
    }

}

ElementType GetNodeID(Node node){
    return node->ID;
}

Graph AddEdge (Graph g, ElementType Start, ElementType End, int weight){
    Node node = SearchNode(g,Start);
    if(node != NULL){
        while(node->next != NULL){
            node = node->next;
        }
        
        Edge new = malloc(sizeof(struct GraphNode));
        new->ID = End;
        new->weight = weight;
        new->next = NULL;
        node->next = new;
    }
    return g;
}

int *GetNeighbours (Graph g, ElementType ID){
    int i = 0;
    int *neighbours = malloc(3 * sizeof(int));

    Node node = SearchNode(g, ID);
    while(node->next != NULL){
        node = node->next;
        neighbours[i] = node->ID;
        i++;
    }
    return neighbours;
}

void printGraph(Graph graph){
    int v; 
    for (v = 0; v < graph->V; ++v) { 
        Node temp = graph->adjlist[v]; 
        printf("\n Adjacency list of vertex %d\n head ", v); 
        while (temp) 
        { 
            printf("-> %d (%d)", temp->ID,temp->weight); 
            temp = temp->next; 
        } 
        printf("\n"); 
    } 
}
