#include <stdio.h>
#include "graph.h"

int main(){
    Node node;
    int *neighbours,i;

    Graph G = ConstructGraph(8);
    //int V = GetNumberOfNodes(G);
    //printf("%u\n",V);

    for(i = 0 ; i <= 7 ; ++i){
        G = AddNode(G,i);
    }

    //node = SearchNode(G,1);
    //printf("%d\n",GetNodeID(node));

    G = AddEdge(G,0,1,5);
    G = AddEdge(G,0,2,5);
    G = AddEdge(G,1,2,3);
    G = AddEdge(G,1,4,2);
    G = AddEdge(G,2,4,4);
    G = AddEdge(G,3,6,5);
    G = AddEdge(G,4,3,1);
    G = AddEdge(G,5,2,4);
    G = AddEdge(G,6,4,4);
    G = AddEdge(G,6,7,2);
    G = AddEdge(G,7,5,3);


/*
    G = AddEdge(G,1,2,5);
    G = AddEdge(G,1,3,5);
    G = AddEdge(G,2,3,3);
    G = AddEdge(G,2,5,2);
    G = AddEdge(G,3,5,4);
    G = AddEdge(G,4,7,5);
    G = AddEdge(G,5,4,1);
    G = AddEdge(G,6,3,4);
    G = AddEdge(G,7,5,4);
    G = AddEdge(G,7,8,2);
    G = AddEdge(G,8,6,3);
*/
    printGraph(G);
    return 0;
}