typedef unsigned int ElementType;

#ifndef Graph_H
#define _Graph_H

struct GraphNode;
typedef struct GraphNode *PtrToGraphNode;
typedef PtrToGraphNode Edge;
typedef PtrToGraphNode Node;
struct GraphADT;
typedef struct GraphADT *PtrToGraph;
typedef PtrToGraph Graph;
struct subset;

Graph ConstructGraph(unsigned int V);
unsigned int GetNumberOfNodes (Graph g);
Graph AddNode(Graph g, ElementType X);
Node SearchNode(Graph g, ElementType X);
ElementType GetNodeID(Node node);
Graph AddEdge (Graph g, ElementType Start, ElementType End, int weight);
int *GetNeighbours (Graph g, ElementType ID);
void printGraph(Graph graph);

#endif
