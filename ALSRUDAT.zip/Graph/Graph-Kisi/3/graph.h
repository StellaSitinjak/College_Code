typedef unsigned int ElementType;

#ifndef Graph_H
#define _Graph_H

struct GraphNode;
typedef struct GraphNode* PtrToGraphNode;
typedef PtrToGraphNode Edge;
typedef PtrToGraphNode Node;
struct GraphADT;
typedef struct GraphADT *PtrToGraph;
typedef PtrToGraph Graph;
struct sub;
typedef struct sub *PtrToSubset;
typedef PtrToSubset Subset;

void printGraph(Graph graph);
Graph ConstructGraph(ElementType V,ElementType E);
Graph AddEdge (Graph g, ElementType Start, ElementType End, int weight);


int myComp(const void* a, const void* b);
int find(Subset subsets, int i) ;
void Union(Subset subsets, int x, int y);

#endif
