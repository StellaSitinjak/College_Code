#include <stdio.h>
#include <stdlib.h>
#include "graph.h"

struct GraphNode{
    int src, dest, weight; 
};

struct GraphADT{
    unsigned int V,E;
    Edge edge;
};

struct sub 
{ 
    ElementType parent; 
    ElementType rank; 
}; 

Graph ConstructGraph(ElementType V,ElementType E){
    Graph graph = malloc(sizeof(struct GraphADT));
    graph->V = V;
    graph->E = E;
    graph->edge  = malloc(V * sizeof(PtrToGraphNode));
    
    return graph;
};

Graph AddEdge (Graph g, ElementType Start, ElementType End, int weight){
    
}

void printGraph(Graph graph){
    int v; 
    for (v = 0; v < graph->V; ++v) { 
        Node temp = graph->edge[v]; 
        printf("\n Adjacency list of vertex %d\n head ", v); 
        while (temp) 
        { 
            printf("-> %d (%d)", temp->src,temp->weight); 
            temp = temp->next; 
        } 
        printf("\n"); 
    } 
}

//Kruskal starts here

int find(Subset subsets, int i) { 
    if (subsets[i].parent != i) 
        subsets[i].parent = find(subsets, subsets[i].parent); 
  
    return subsets[i].parent; 
} 
  
void Union(Subset subsets, int x, int y) { 
    int xroot = find(subsets, x); 
    int yroot = find(subsets, y); 
  
    if (subsets[xroot].rank < subsets[yroot].rank) 
        subsets[xroot].parent = yroot; 
    else if (subsets[xroot].rank > subsets[yroot].rank) 
        subsets[yroot].parent = xroot;   
    else{ 
        subsets[yroot].parent = xroot; 
        subsets[xroot].rank++; 
    } 
} 

void KruskalMST(Graph graph) { 
    int V = graph->V; 
    Node result[V];  
    int e = 0, i = 0; 
    
    qsort(graph->edge, graph->V, sizeof(graph->edge), myComp); 
  
    Subset subsets = (Subset) malloc( V * sizeof(Subset) ); 
  
    for (int v = 0; v < V; ++v) { 
        subsets[v].parent = v; 
        subsets[v].rank = 0; 
    } 
  
    while (e < V - 1) { 
        Edge next_edge = graph->edge[i++]; 
  
        int x = find(subsets, GetNodeID(next_edge)); 
        int y = find(subsets, GetNodeWeight(next_edge)); 
  
        if (x != y) { 
            result[e++] = next_edge; 
            Union(subsets, x, y); 
        } 
    } 
  
    printf("Following are the edges in the constructed MST\n"); 
    for (i = 0; i < e; ++i) 
        printf("%d -- %d == %d\n", result[i]->src, result[i]->dest, 
                                                 result[i]->weight); 
    return; 
} 

int myComp(const void* a, const void* b) { 
    Edge a1 = (Edge)a; 
    Edge b1 = (Edge)b; 
    return a1->weight > b1->weight; 
} 