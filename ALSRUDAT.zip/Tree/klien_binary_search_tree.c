/*
Nama: Stella Ditri Almeyda Sitinjak
NIM: 12S17027

Nama: Silvany Angelia Lumban Gaol
NIM: 12S17029

Nama: Fradina Sinambela
NIM: 12S17067
*/

#include "binary_search_tree.h"
#include <stdio.h>

int main(){
	BinarySearchTree T;
	Position P = NULL;
	
	T = MakeEmpty(NULL); //fungsi untuk mengosongkan binary search tree
	printf("Done!\n");
	
	//pembuatan BinarySearchTree
//	T = Insert(6, T);
//	T = Insert(2, T);
//	T = Insert(8, T);
//	T = Insert(1, T);
//	T = Insert(4, T);
//	T = Insert(3, T);

	T = Insert_Iterative(6, T);
	T = Insert_Iterative(2, T);
	T = Insert_Iterative(8, T);
	T = Insert_Iterative(1, T);
	T = Insert_Iterative(4, T);
	T = Insert_Iterative(3, T);
	printf("\nElemen root : T->Element = %d\n", Retrieve(T));
	
	//Mencetak element secara ascending
	printf("\nElemen:\n");
	PrintInOrder(T);
	 
	//Mencetak banyaknya simpul pada BST
	printf("\nBanyak simpul: %d\n", GetNumNodes(T));
	
	//mencari dan mencetak elemen 3
	P = Find(3, T);
	printf("\nElemen dengan nilai kunci %d ditemukan\n", Retrieve(P));
	
	//mencari elemen minimum
	P = FindMin(T);
	printf("\nElemen (nilai kunci) minimum = %d\n", Retrieve(P));
	
	//mencari elemen maksimum
	P = FindMax(T);
	printf("Elemen (nilai kunci) maksimum = %d\n", Retrieve(P));
	
	//menghapus simpul dengan nilai elemen 2
	T = Delete(2, T);
	
	
	if(Find(2, T) == NULL)
		printf("\nSimpul dengan elemen 2 tidak ditemukan\n");
	else
		printf("Simpul dengan elemen %d ditemukan\n", Retrieve(P));
	
	return 0;
}
