/*
Nama: Stella Ditri Almeyda Sitinjak
NIM: 12S17027

Nama: Silvany Angelia Lumban Gaol
NIM: 12S17029

Nama: Fradina Sinambela
NIM: 12S17067
*/

#include "binary_search_tree.h"
#include <stdlib.h>
#include "fatal.h"

struct TreeNode{
	ElementType Element;
	BinarySearchTree Left;
	BinarySearchTree Right;
};

BinarySearchTree MakeEmpty(BinarySearchTree T){
	if(T != NULL){
		MakeEmpty(T->Left);
		MakeEmpty(T->Right);
		free(T);
	}
	return NULL;
}

//Fungsi Insert Rekursif
BinarySearchTree Insert(ElementType x, BinarySearchTree T){
	if(T == NULL){
		T = malloc(sizeof(struct TreeNode));
		if(T == NULL)
			FatalError("Out of space!!!");
		else{
			T->Element = x;
			T->Left = T->Right = NULL;
		}
	}
	else if(x < T->Element){
		T->Left = Insert(x, T->Left);
	}
	else if(x > T->Element){
		T->Right = Insert(x, T->Right);
	}
	//printf("C imp: T->Element = %d \n", T->Element);
	
	return T;
}

//Fungsi Insert Iteratif
BinarySearchTree Insert_Iterative(ElementType x, BinarySearchTree T){
	BinarySearchTree Node = malloc(sizeof(struct TreeNode));
	Node->Element = x;
	Node->Right = Node->Left = NULL;
	if(T == NULL){
		return Node;
	}
	BinarySearchTree Parent = NULL, Current = T;
	while(Current != NULL){
		Parent = Current;
		if(x >= Current->Element){
			Current = Current->Right;
		}
		else{
			Current = Current->Left;
		}
	}
	if(x >= Parent->Element){
		Parent->Right = Node;
	}
	else{
		Parent->Left = Node;
	}
	return T;
}

ElementType Retrieve(Position P){
	return P->Element;
}

Position Find(ElementType x, BinarySearchTree T){
	if(T == NULL)
		return NULL;
	else if(x == T->Element)
		return T;
	else if(x < T->Element)
		return Find(x, T->Left);
	else if(x > T->Element)
		return Find(x, T->Right);
}

Position FindMin(BinarySearchTree T){
	if(T == NULL)
		return NULL;
	else if(T->Left == NULL)
		return T;
	else
		return FindMin(T->Left);
}

Position FindMax(BinarySearchTree T){
	if(T != NULL)
		while(T->Right != NULL)
			T = T->Right;
	return T;
}

BinarySearchTree Delete(ElementType x, BinarySearchTree T){
	Position TmpCell;
	
	if(T == NULL)
		Error("Element not found");
	else if(x < T->Element) /*Go Left*/
		T->Left = Delete (x, T->Left);
	else if(x > T->Element) /*Go Right*/
		T->Right = Delete(x, T->Right);
	else /* Found element to be deleted*/
		if(T->Left && T->Right ){ /*Two children*/
			/* Replace with smallest in right subtree*/
			TmpCell = FindMin(T->Right);
			T->Element = TmpCell->Element;
			T->Right = Delete(T->Element, T->Right);
		}
		else{ /* One or zero children*/
			TmpCell = T;
			if(T->Left == NULL) /* Also handles 0 children*/
				T = T->Right;
			else if(T->Right == NULL)
				T = T->Left;
			free(TmpCell);
		}
	return T;
}

unsigned int GetNumNodes(BinarySearchTree T){
	if(T == NULL)
		return 0;
	else
		return GetNumNodes(T->Left) + 1 + GetNumNodes(T->Right);
}

void PrintInOrder(BinarySearchTree T){
	if(T != NULL){
		PrintInOrder(T->Left);
		printf("%d\n", T->Element);
		PrintInOrder(T->Right);
	}
}
