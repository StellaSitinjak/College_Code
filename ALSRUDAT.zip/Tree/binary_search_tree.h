/*
Nama: Stella Ditri Almeyda Sitinjak
NIM: 12S17027

Nama: Silvany Angelia Lumban Gaol
NIM: 12S17029

Nama: Fradina Sinambela
NIM: 12S17067
*/

typedef int ElementType;

#ifndef _Tree_H
#define _Tree_H

struct TreeNode;
typedef struct TreeNode *Position;
typedef struct TreeNode *BinarySearchTree;

BinarySearchTree Insert(ElementType x, BinarySearchTree T);
BinarySearchTree Insert_Iterative(ElementType x, BinarySearchTree T);
Position Find(ElementType x, BinarySearchTree T);
ElementType Retrieve(Position P);
BinarySearchTree MakeEmpty(BinarySearchTree T);
Position FindMin(BinarySearchTree T);
Position FindMax(BinarySearchTree T);
BinarySearchTree Delete(ElementType x, BinarySearchTree T);
void PrintInOrder(BinarySearchTree T);
unsigned int GetNumNodes(BinarySearchTree T);

#endif
