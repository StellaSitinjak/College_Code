/*
Nama: Stella Ditri Almeyda Sitinjak
NIM: 12S17027

Nama: Silvany Angelia Lumban Gaol
NIM: 12S17029

Nama: Fradina Sinambela
NIM: 12S17067
*/

#include <stdio.h>
#include <stdlib.h>

#define Error(Str)		FatalError(Str)
#define FatalError(Str)	fprintf( stderr, "%s\n", Str), exit( 1 )
