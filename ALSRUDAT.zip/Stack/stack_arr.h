/*
Nama : Stella Ditri Almeyda Sitinjak
NIM : 12S17027

Nama : Silvany Angelia Lumban Gaol
NIM : 12S17029

Nama : Fradina Sinambela
NIM : 12S17067
*/

#ifndef _Stack_S
#define _Stack_S

typedef int ElementType;
struct StackRecord;
typedef struct StackRecord *Stack;

Stack CreateStack(int MaxElements);
void Push(Stack S, ElementType x);
void Pop(Stack S);
ElementType Top(Stack S);
void Destroy(Stack S);
void Show(Stack S);

#endif
