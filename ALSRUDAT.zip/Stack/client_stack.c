/*
Nama : Stella Ditri Almeyda Sitinjak
NIM : 12S17027

Nama : Silvany Angelia Lumban Gaol
NIM : 12S17029

Nama : Fradina Sinambela
NIM : 12S17067
*/

#include <stdio.h>
#include <stdlib.h>
#include "stack_arr.h"

int main(){
	Stack S = NULL;
	int n, input, menu;
	
	printf("Kapasitas Stack: ");
	scanf("%d", &n);
	S = CreateStack(n);
	
	printf("Menu:\n1. Push\n2. Pop\n3. Top\n4. Destroy\n5. Show\n0. Exit\n");
	do{
		scanf("%d", &menu);
		switch (menu){
			case 1:
				printf("Masukan: ");
				scanf("%d", &input);
				Push(S, input);
				break;
			case 2:
				Pop(S);
				break;
			case 3:
				printf("Element: %d\n", Top(S));
				break;
			case 4:
				Destroy(S);
				break;
			case 5:
				Show(S);
				break;
		}
	}while(menu != 0);
	
	return 0;
}
