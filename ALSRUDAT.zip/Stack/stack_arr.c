/*
Nama : Stella Ditri Almeyda Sitinjak
NIM : 12S17027

Nama : Silvany Angelia Lumban Gaol
NIM : 12S17029

Nama : Fradina Sinambela
NIM : 12S17067
*/

#include <stdio.h>
#include <stdlib.h>
#include "stack_arr.h"

struct StackRecord{
	int Capacity;
	int Top;
	int Size;
	ElementType *Array;
};

Stack CreateStack(int MaxElements){
	Stack S = malloc(sizeof (struct StackRecord));
	S->Top = -1;
	S->Capacity = MaxElements;
	S->Size = 0;
	S->Array = malloc(sizeof (ElementType) * MaxElements);
	return S;
}
void Push(Stack S, ElementType x){
	if(S->Size < S->Capacity){
		S->Top++;
		S->Array[S->Top] = x;
		S->Size++;
	}
	else{
		printf("Stack is full!\n");
	}
}

void Pop(Stack S){
	if(S->Size != 0){
		S->Top--;
		S->Size--;
		printf("Done!\n");
	}
	else{
		printf("Stack is empty!\n");
	}
}

ElementType Top(Stack S){
	return S->Array[S->Top];
}

void Destroy(Stack S){
	free(S->Array);
	free(S);
	printf("Stack is Empty!\n");
}

void Show(Stack S){
	int i = 0;
	while(i < S->Size){
		printf("%d\t", S->Array[i]);
		i++;
	}
	printf("\n");
}

