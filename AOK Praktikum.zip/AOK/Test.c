#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(){
	int i, count=0, temp=0;
	char _string[50], word[20], type[20], meaning[20];
	char tag = '#';
	gets(_string);
	//Search Word
	for(i=4; i<strlen(_string); i++){
		if(_string[i]!=tag){
			word[count] = _string[i];
		}else{
			goto next1;
		}
		count++;
	}
	//Search Type
	next1:
	temp = count+1;
	count = 0;
	for(i=temp; i<strlen(_string); i++){
		if(_string[i]!=tag){
			type[count] = _string[i];
		}else{
			break;
		}
		count++;
	}
	/*//Search Meaning
	temp = count+1;
	printf("%d", temp);
	count = 0;
	for(i=temp; i<strlen(_string); i++){
		if(tag!=_string[i]){
			meaning[count] = _string[i];
		}else{
			break;
		}
		count++;
	}
	*/
	printf("%s\n", word);
	printf("%s\n", type);
	//printf("%s\n", meaning);
	return 0;
}
