#include <stdio.h>
void display(int);

int main(){
	int array[] = {2, 8, 4, 9};
	int *i = array, j;
	
	for(j = 0; array[j] != '\0'; j++){
		printf("Nilai elemen ke-%d = %d\n", j+1, *i);
		i++;	
	}
	printf("Alamat elemen pertama array = %d\n", &array);

	return 0;
}

